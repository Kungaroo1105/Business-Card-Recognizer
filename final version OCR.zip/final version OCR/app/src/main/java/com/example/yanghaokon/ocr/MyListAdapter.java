package com.example.yanghaokon.ocr;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by compsci on 9/26/15.
 */
public class MyListAdapter extends BaseAdapter {
    private Context c2v_context;
    private ArrayList<MyListData> c2v_listItems;
    public MyListAdapter(Context context, ArrayList<MyListData> listItems){
        this.c2v_context = context;
        this.c2v_listItems = listItems;
    }



    @Override
    public int getCount() {
        return c2v_listItems.size();
    }

    @Override
    public Object getItem(int position) {
        return c2v_listItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            LayoutInflater mInflater = (LayoutInflater)
                    c2v_context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            convertView = mInflater.inflate(R.layout.my_listcell, null);
        }


        TextView lv_modelLbl = (TextView) convertView.findViewById(R.id.xv2_symbolLbl);
        lv_modelLbl.setText(c2v_listItems.get(position).getSymbol());

        return convertView;
    }

}
