package com.example.yanghaokon.ocr;

import android.os.StrictMode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by yanghiroshikon on 15/10/2.
 */
public class getData {

    public String getIt(String a) {
        String lv_str = cfp_downloadHttp(a);
        return lv_str;
    }



    private String cfp_readStream(InputStream in) {
        BufferedReader lv_reader = null;
        StringBuilder lv_sb = new StringBuilder();
        try {
            lv_reader = new BufferedReader(new InputStreamReader(in));
            String nextLine = "";
            while ((nextLine = lv_reader.readLine()) != null) {
                lv_sb.append(nextLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (lv_reader != null) {
                try {
                    lv_reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return lv_sb.toString();
        }
    }
    private String cfp_downloadHttp(String url) {
        String lv_str = "";

        StrictMode.ThreadPolicy policy = new StrictMode.
                ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            URL lv_url = new URL(url);
            HttpURLConnection lv_con = (HttpURLConnection) lv_url.openConnection();
            lv_str = cfp_readStream(lv_con.getInputStream());

            // may add more as in http://www.tutorialspoint.com/android/android_network_connection.htm
            /*if (!(urlConn instanceof HttpURLConnection)) {
                throw new IOException("URL is not an Http URL");
            }
            HttpURLConnection httpConn = (HttpURLConnection) urlConn;
            httpConn.setAllowUserInteraction(false);
            httpConn.setInstanceFollowRedirects(true);
            httpConn.setRequestMethod("GET");
            httpConn.connect();
            resCode = httpConn.getResponseCode();

            if (resCode == HttpURLConnection.HTTP_OK) {
                in = httpConn.getInputStream();
            }*/
        } catch (Exception e) {
            e.printStackTrace();
            lv_str = "Connection error: " + e.toString();
        }

        return lv_str;
    }



}
