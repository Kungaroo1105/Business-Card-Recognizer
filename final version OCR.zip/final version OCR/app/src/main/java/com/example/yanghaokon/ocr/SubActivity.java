package com.example.yanghaokon.ocr;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

/**
 * Created by yanghiroshikon on 15/10/3.
 */
public class SubActivity extends AppCompatActivity {


    TextView tv_name;
    TextView tv_org;
    TextView tv_tel;
    TextView tv_email;
    TextView tv_addr;
    TextView tv_note;

    MyDBHelper lv_dbPersonal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent);
        tv_name=(TextView)findViewById(R.id.tv_name_int);
        tv_org=(TextView)findViewById(R.id.inttv_org);
        tv_tel=(TextView)findViewById(R.id.inttv_tel);
        tv_email=(TextView)findViewById(R.id.inttv_email);
        tv_addr=(TextView)findViewById(R.id.inttv_add);
        tv_note=(TextView)findViewById(R.id.inttv_note);

        lv_dbPersonal = new MyDBHelper(this);
        lv_dbPersonal.dbf_initRows();

        Bundle extras = getIntent().getExtras();
        String id = extras.getString("Name");

        tv_name.setText(id);
        tv_org.setText(lv_dbPersonal.dbf_getOrgRecords(id));
        tv_tel.setText(lv_dbPersonal.dbf_getTelRecords(id));
        tv_email.setText(lv_dbPersonal.dbf_getEmailRecords(id));
        tv_addr.setText(lv_dbPersonal.dbf_getAddrRecords(id));
        tv_note.setText(lv_dbPersonal.dbf_getNoteRecords(id));


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Back");


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //back button as menuitem, no need of onCreateOptionsMenu(Menu menu)
        if (id == android.R.id.home) {
            cfp_navBack();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        cfp_navBack();
    }

    private void cfp_navBack() {
        Intent lv_it = new Intent(this, MainActivity.class);
        startActivity(lv_it);
        overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);

    }


}

