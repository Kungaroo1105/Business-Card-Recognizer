package com.example.yanghaokon.ocr;

/**
 * Created by compsci on 9/26/15.
 */
public class MyListData {
    private String mv_symbol;
//    private String mv_name;
//    private String mv_bid;
//    private String mv_lastTrade;
//    private String mv_ask;
//    private String mv_change;
//    private String mv_color;




    public MyListData(String symbol){
        this.mv_symbol = symbol;
//        this.mv_name = name;
//        this.mv_bid = bid;
//        this.mv_lastTrade = lastTrade;
//        this.mv_ask = ask;
//        this.mv_change = change;
//        this.mv_color = color;
    }

    public String getSymbol(){
        return this.mv_symbol;
    }
//    public String getName(){
//        return this.mv_name;
//    }
//    public String getBid(){
//        return this.mv_bid;
//    }
//    public String getLastTrade(){
//        return this.mv_lastTrade;
//    }
//    public String getAsk(){
//        return this.mv_ask;
//    }
//    public String getChange(){
//        return this.mv_change;
//    }
//    public String getColor(){
//        return this.mv_color;
//    }


   /*

    public void setModel(String model){
        this.mv_model = model;
    }

    public void setName(String name){
        this.mv_name = name;
    }

    public void setPrice(int price){
        this.mv_price = price;
    }
*/
}
