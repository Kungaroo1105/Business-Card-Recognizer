package com.example.yanghaokon.ocr;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.app.AlertDialog;
import android.app.Dialog;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
	MainActivity cv_this = this;
	ArrayList<String> nameArray;
	ArrayList<MyListData> lv_listItems = new ArrayList<MyListData>();
	MyListAdapter cv_adapter = new MyListAdapter(this,
			lv_listItems);
	String[] transData= new String[6];

	MyDBHelper cv_db;
	Button btn_photo;
	public boolean intented = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		cv_db = new MyDBHelper(this);
		cv_db.dbf_initRows();
		nameArray = cv_db.dbf_getAllRecords();
		if(getIntent()!=null){
			Bundle extras = getIntent().getExtras();
			if (extras!=null){
				String name = extras.getString("Name");
				String org = extras.getString("Org");
				String add = extras.getString("Addr");
				String tel = extras.getString("Tel");
				String email = extras.getString("Email");
				String note = extras.getString("Note");
				Log.d("////////",""+name);
//                transData[0]=name;
//                transData[1]=org;
//                transData[2]=add;
//                transData[3]=tel;
//                transData[4]=email;
//                transData[5]=note;
//                String thing = transData[0];
				cv_db.dbf_appendPart(name, org, add, tel, email, note);
				lv_listItems.clear();
				nameArray.clear();
				//symbolArray = new ArrayList<String>(Arrays.asList(data));;
				nameArray = cv_db.dbf_getAllRecords();
				cv_adapter.notifyDataSetChanged();
			}

		}
//        if(intented == true) {
//            Bundle extras = getIntent().getExtras();
//            String name = extras.getString("Name");
//            transData[0]=name;
//            Log.d("////////////////////","true");
//            intented=false;
//        }

		for (int i = 0; i < nameArray.size(); i++) {
			lv_listItems.add(new MyListData(nameArray.get(i)));
		}


		final ListView listView = (ListView) findViewById(R.id.xv_tabletList);
		listView.setAdapter(cv_adapter);

		listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			public boolean onItemLongClick(AdapterView<?> parent, View view,
										   final int position, long id) {
//                cv_db.dbf_deletePart(nameArray.get(position));
//                lv_listItems.remove(position);
//                cv_adapter.notifyDataSetChanged();
//                //Log.d("Debug",symbolArray.get(1)+" ");
//                return true;





				AlertDialog.Builder set_builder = new AlertDialog.Builder(MainActivity.this);
				set_builder.setTitle("Delete info?");//设置对话框标题
				set_builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {//添加确定按钮
					@Override
					public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件

						AlertDialog.Builder set_builder1 = new AlertDialog.Builder(MainActivity.this);
						set_builder1.setTitle("This Info would be permanently lost");//设置对话框标题
						set_builder1.setPositiveButton("Delete it anyway", new DialogInterface.OnClickListener() {//添加确定按钮
							@Override
							public void onClick(DialogInterface dialog, int which) {


								// TODO Auto-generated method stub
								cv_db.dbf_deletePart(nameArray.get(position));
								lv_listItems.remove(position);
								cv_adapter.notifyDataSetChanged();
								//Log.d("Debug",symbolArray.get(1)+" ");
							}
						});
						set_builder1.setNegativeButton("Back", new DialogInterface.OnClickListener() {//添加返回按钮

							@Override
							public void onClick(DialogInterface dialog, int which) {//响应事件
								// TODO Auto-generated method stub

							}
						});
						set_builder1.show();
					}
				});
				set_builder.setNegativeButton("Back", new DialogInterface.OnClickListener() {//添加返回按钮

					@Override
					public void onClick(DialogInterface dialog, int which) {//响应事件
						// TODO Auto-generated method stub

					}
				});

				set_builder.show();//在按键响应事件中显示此对话框



				return true;}

		});

		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
									int position, long id) {
				Intent lv_it = new Intent(cv_this, SubActivity.class);
				MyListData lv_data = (MyListData) cv_adapter.getItem(position);
				lv_it.putExtra("Name", lv_data.getSymbol());
				startActivity(lv_it);
				overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
			}
		});

		btn_photo = (Button)findViewById(R.id.btn_photo);
		btn_photo.setOnClickListener(this);
	}


	@Override
	public void onClick(View view)
	{
		switch (view.getId())
		{



			case R.id.btn_photo:
				Intent lv_it_scanner = new Intent(cv_this, ScannerActivity.class);
				startActivity(lv_it_scanner);
				break;


			////////////////////
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}



}
