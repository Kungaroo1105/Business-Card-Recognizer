package com.example.yanghaokon.ocr;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by compsci on 10/15/15.
 */
public class MyDBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "myDemo.db";
    public static final String TABLE_NAME = "myTable";

    public MyDBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(
                "CREATE TABLE myTable " +
                        "(NAME TEXT PRIMARY KEY NOT NULL, ORG TEXT, TEL TEXT, EMAIL TEXT, ADDR TEXT, NOTE TEXT)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean dbf_initRows() {
        if (dbf_numberOfRows() == 0) {
            SQLiteDatabase db = this.getWritableDatabase();

            db.execSQL("INSERT INTO myTable VALUES('Gregory McKinstry','Eastern Michigan University','XXX,XXX,XXXX','gmckinst@emich.edu','EMU Dorm','Developper');");
            db.execSQL("INSERT INTO myTable VALUES('Haokun Yang','Eastern Michigan University','XXX,XXX,XXXX','hyang6@emich.edu','EMU Dorm','Developper');");
            db.execSQL("INSERT INTO myTable VALUES('Wenjing Shangguan','Eastern Michigan University','XXX,XXX,XXXX','wshanggu@emich.edu','EMU Dorm','Developper');");
            db.execSQL("INSERT INTO myTable VALUES('Jingchao Yang','Eastern Michigan University','XXX,XXX,XXXX','jyang19@emich.edu','EMU Dorm','Developper');");


            db.close();
            return true;
        } else {
            return false;
        }
    }

    public int dbf_numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, TABLE_NAME);
        db.close();
        return numRows;
    }


    public ArrayList<String> dbf_getAllRecords() {
        ArrayList<String> lv_list = new ArrayList<String>();
        String selectQuery = "SELECT NAME FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                lv_list.add(cursor.getString(cursor.getColumnIndex("NAME")));
            } while (cursor.moveToNext());
        }
        db.close();

        return lv_list;
    }

    public String dbf_getOrgRecords(String name) {
        String o = "Apple";
        String selectQuery = "SELECT ORG FROM " + TABLE_NAME+" WHERE NAME =\"" + name + "\"";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                return o = cursor.getString(0);
            }while (cursor.moveToNext());
        }
        return o;
    }

    public String dbf_getTelRecords(String name) {
        String o = "Apple";
        String selectQuery = "SELECT TEL FROM " + TABLE_NAME+" WHERE NAME =\"" + name + "\"";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                return o = cursor.getString(0);
            }while (cursor.moveToNext());
        }
        return o;
    }
    public String dbf_getEmailRecords(String name) {
        String o = "Apple";
        String selectQuery = "SELECT EMAIL FROM " + TABLE_NAME+" WHERE NAME =\"" + name + "\"";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                return o = cursor.getString(0);
            }while (cursor.moveToNext());
        }
        return o;
    }
    public String dbf_getAddrRecords(String name) {
        String o = "Apple";
        String selectQuery = "SELECT ADDR FROM " + TABLE_NAME+" WHERE NAME =\"" + name + "\"";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                return o = cursor.getString(0);
            }while (cursor.moveToNext());
        }
        return o;
    }
    public String dbf_getNoteRecords(String name) {
        String o = "Apple";
        String selectQuery = "SELECT NOTE FROM " + TABLE_NAME+" WHERE NAME =\"" + name + "\"";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                return o = cursor.getString(0);
            }while (cursor.moveToNext());
        }
        return o;
    }

    public void dbf_deletePart(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME + " WHERE NAME = '" + name + "'");
        db.close();
    }

    public void dbf_appendPart(String name, String org,String tel,String email, String addr, String note) {

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor1 = db.rawQuery("SELECT * FROM "+ TABLE_NAME + " WHERE NAME= \"" + name + "\"" , null);
        if (cursor1.moveToNext()) {
            Log.d("/////////////", "Already exist");

        cursor1.close();}
        else {
            db.execSQL("INSERT INTO " + TABLE_NAME + " VALUES('" + name + "','" + org + "','" + tel + "','" + email + "','" + addr + "','" + note + "');");
            //System.out.println("//////////////INSERT INTO " + TABLE_NAME + " VALUES('" + name + "','" + org  + "','" + tel + "','" + email + "','" + addr + "','" + note + "');");
        }
        db.close();
    }
}


