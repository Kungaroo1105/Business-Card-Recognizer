package com.example.yanghaokon.ocr;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * Created by hyang6 on 4/1/16.
 */


public class ScannerActivity extends Activity implements View.OnClickListener{
    //	static {
//		System.loadLibrary("lept");
//	}
    ScannerActivity cv_this = this;
    private static final int PHOTO_CAPTURE = 0x11;// ����
    private static final int PHOTO_RESULT = 0x12;// ���

    private static String LANGUAGE = "eng";
    public static String IMG_PATH = getSDPath() + File.separator
            + "ocrtest";

    private static TextView tvResult;
    private static ImageView ivSelected;
    private static ImageView ivTreated;
    private static Button btnCamera;
    private static Button btnSelect;
    private static Button btnContinue;
    private static CheckBox chPreTreat;
    private static String textResult;
    private static Bitmap bitmapSelected;
    private static Bitmap bitmapTreated;
    private static final int SHOWRESULT = 0x101;
    private static final int SHOWTREATEDIMG = 0x102;

    ArrayList<String> namelist = new ArrayList<String>();
    ArrayList<String> orglist = new ArrayList<String>();
    ArrayList<String> emaillist = new ArrayList<String>();
    ArrayList<String> tellist = new ArrayList<String>();
    ArrayList<String> addlist = new ArrayList<String>();
    ArrayList<String> notelist = new ArrayList<String>();

    static {
        //System.loadLibrary("lept");

    }



    // ��handler���ڴ����޸Ľ�������
    public static Handler myHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SHOWRESULT:
                    if (textResult.equals(""))
                        tvResult.setText("Recognizing 80%");
                    else
                        tvResult.setText(textResult);
                    break;
                case SHOWTREATEDIMG:
                    tvResult.setText("Recognizing 50%");
                    showPicture(ivTreated, bitmapTreated);
                    break;
            }
            super.handleMessage(msg);
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scanner);

        // ���ļ��в����� ���ȴ����ļ���
        File path = new File(IMG_PATH);
        if (!path.exists()) {
            path.mkdirs();
        }

        tvResult = (TextView) findViewById(R.id.tv_result);
        ivSelected = (ImageView) findViewById(R.id.iv_selected);
        ivTreated = (ImageView) findViewById(R.id.iv_treated);
        btnCamera = (Button) findViewById(R.id.btn_camera);
        btnSelect = (Button) findViewById(R.id.btn_select);
        btnContinue = (Button) findViewById(R.id.btn_continue);
        chPreTreat = (CheckBox) findViewById(R.id.ch_pretreat);

        btnCamera.setOnClickListener(new cameraButtonListener());
        btnSelect.setOnClickListener(new selectButtonListener());
        btnContinue.setOnClickListener(this);
        btnContinue.setEnabled(false);

        // �������ý�������
//		radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
//
//			@Override
//			public void onCheckedChanged(RadioGroup group, int checkedId) {
//				switch (checkedId) {
//					case R.id.rb_en:
//						LANGUAGE = "eng";
//						break;
//					case R.id.rb_ch:
//						LANGUAGE = "chi_sim";
//						break;
//				}
//			}
//
//		});

    }

//	@Override
//	public boolean onCreateOptionsMenu(Menu menu) {
//		// Inflate the menu; this adds items to the action bar if it is present.
//		getMenuInflater().inflate(R.menu.main, menu);
//		return true;
//	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == Activity.RESULT_CANCELED)
            return;

        if (requestCode == PHOTO_CAPTURE) {
            tvResult.setText("abc");
            startPhotoCrop(Uri.fromFile(new File(IMG_PATH, "temp.jpg")));
        }

        // ������
        if (requestCode == PHOTO_RESULT) {
            bitmapSelected = decodeUriAsBitmap(Uri.fromFile(new File(IMG_PATH,
                    "temp_cropped.jpg")));
            System.out.print("///////////Width:" + bitmapSelected.getWidth());


            if (chPreTreat.isChecked())
                tvResult.setText("Processing");
            else
                tvResult.setText("Processed failed");

            // ��ʾѡ���ͼƬ
            showPicture(ivSelected, bitmapSelected);

            // ���߳�������ʶ��
            new Thread(new Runnable() {
                @Override
                public void run() {
                    //Bitmap rawBitmap = BitmapFactory.decodeResource(getResources(),R.drawable.test);
                    //System.out.println(doOcr(rawBitmap,"eng") + "/////////");
                    if (chPreTreat.isChecked()) {
                        if (ImgPretreatment.processed = false) {
                            textResult = "Failed, please try again!";
                        } else {
                            bitmapTreated = ImgPretreatment
                                    .doPretreatment(bitmapSelected);
                            Message msg = new Message();
                            msg.what = SHOWTREATEDIMG;
                            myHandler.sendMessage(msg);
                            textResult = doOcr(bitmapTreated, LANGUAGE);
                        }
                    } else {
                        bitmapTreated = ImgPretreatment
                                .converyToGrayImg(bitmapSelected);
                        Message msg = new Message();
                        msg.what = SHOWTREATEDIMG;
                        myHandler.sendMessage(msg);
                        textResult = doOcr(bitmapTreated, LANGUAGE);
                    }
                    String[] recognizedString;
                    String[] OCRSplit;
                    Log.d("///////////before", textResult);
                    textResult = characterFilter(textResult);
                    Log.d("//////////after", textResult);
                    OCRSplit = Split(textResult);

                    //A for loop, loops through the split string
                    //uses the recognizer method
                    for (int i = 0; i < OCRSplit.length; i++) {
                        if (OCRSplit[i].length() > 5) {
                            //Was the string recognized?
                            recognizedString = Recognizer(OCRSplit[i]);
                            //output to log
                            // System.out.println(recognizedString[0] + ": " + recognizedString[1]);
                            Log.d("Finally/////////////", "Type: " + recognizedString[0] + " String: " + recognizedString[1]);
                            Log.d("///////", recognizedString[0]);
                            if (recognizedString[0]=="name"){
                                namelist.add(recognizedString[1]);
                            }

                            if (recognizedString[0]=="email"){
                                emaillist.add(recognizedString[1]);
                            }

                            if (recognizedString[0]=="telephone"){
                                tellist.add(recognizedString[1]);
                            }

                            if (recognizedString[0]=="street" || recognizedString[0]=="area" || recognizedString[0]=="apartment"){
                                addlist.add(recognizedString[1]);
                            }

                            if (recognizedString[0]=="notrecognized" ){
                                notelist.add(recognizedString[1]);
                            }
                            if (recognizedString[0]=="fax" ){
                                notelist.add(recognizedString[1]);
                            }


                        }
                    }
                    Log.d("//////name",namelist.size()+"");
                    Log.d("//////email",emaillist.size()+"");
                    Log.d("//////tel",tellist.size()+"");
                    Log.d("//////add",addlist.size()+"");
                    Log.d("//////note",notelist.size()+"");

                    Message msg2 = new Message();
                    msg2.what = SHOWRESULT;
                    myHandler.sendMessage(msg2);
                }

            }).start();
                btnContinue.setEnabled(true);
        }

//        Intent intent = new Intent(ScannerActivity.this, ProfilePageActivity.class);
//        Bundle bundle = new Bundle();
//        bundle.putString("Name", "Yang Haokun");
//        intent.putExtras(bundle);
//
//        startActivity(intent);

        super.onActivityResult(requestCode, resultCode, data);
    }

    // ����ʶ��
    class cameraButtonListener implements View.OnClickListener {

        @Override
        public void onClick(View arg0) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT,
                    Uri.fromFile(new File(IMG_PATH, "temp.jpg")));
            startActivityForResult(intent, PHOTO_CAPTURE);
//
//			Bitmap rawBitmap = BitmapFactory.decodeResource(getResources(),R.drawable.test);
//			System.out.println(doOcr(rawBitmap,"eng") + "/////////");
        }
    };

    // �����ѡȡ��Ƭ���ü�
    class selectButtonListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.putExtra("crop", "true");
            intent.putExtra("scale", true);
            intent.putExtra("return-data", false);
            intent.putExtra(MediaStore.EXTRA_OUTPUT,
                    Uri.fromFile(new File(IMG_PATH, "temp_cropped.jpg")));
            intent.putExtra("outputFormat",
                    Bitmap.CompressFormat.JPEG.toString());
            intent.putExtra("noFaceDetection", true); // no face detection
            startActivityForResult(intent, PHOTO_RESULT);
        }

    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btn_continue:
        Intent intent = new Intent(ScannerActivity.this, ProfilePageActivity.class);
        Bundle bundle = new Bundle();

                if (namelist.size()>0){
                for(int i=1; i<=namelist.size();i++){
                    bundle.putString("Name"+i, namelist.get(i-1));
                }
                    bundle.putInt("nameInt", namelist.size());
                    namelist.clear();
                }

                if (emaillist.size()>0){
                    for(int i=1; i<= emaillist.size(); i++) {
                            bundle.putString("Email"+i, emaillist.get(i-1));
                    }
                    bundle.putInt("emailInt", emaillist.size());
                    emaillist.clear();
                }
                if (tellist.size() > 0) {
                    for(int i=1; i<=tellist.size();i++){
                        bundle.putString("Tel"+i, tellist.get(i-1));
                    }
                    bundle.putInt("telInt", tellist.size());
                    tellist.clear();
                }

                if (addlist.size()>0){
                    for(int i=1; i<=addlist.size();i++){
                        bundle.putString("Add"+i, addlist.get(i-1));
                    }
                    bundle.putInt("addInt", addlist.size());
                    addlist.clear();
                }
                if (notelist.size()>0){
                    for(int i=1; i<=notelist.size();i++){
                        bundle.putString("Note"+i, notelist.get(i-1));
                    }
                    bundle.putInt("noteInt", notelist.size());
                    notelist.clear();
                }



        intent.putExtras(bundle);
        startActivity(intent);
                break;
        }

    }


    // ��ͼƬ��ʾ��view��
    public static void showPicture(ImageView iv, Bitmap bmp){
        iv.setImageBitmap(bmp);
    }

    /**
     * ����ͼƬʶ��
     *
     * @param bitmap
     *            ��ʶ��ͼƬ
     * @param language
     *            ʶ������
     * @return ʶ�����ַ�
     */
    public String doOcr(Bitmap bitmap, String language) {


        TessBaseAPI baseApi = new TessBaseAPI();

        baseApi.init(getSDPath(), language);

        // ����Ӵ��У�tess-twoҪ��BMP����Ϊ������

        String text=" ";
        try {
            bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
            baseApi.setImage(bitmap);
            text = baseApi.getUTF8Text();
            baseApi.clear();
            baseApi.end();

        } catch (IndexOutOfBoundsException e) {
            System.err.println("IndexOutOfBoundsException: " + e.getMessage());
        }
        return text;

    }

    /**
     * ��ȡsd����·��
     *
     * @return ·�����ַ�
     */
    public static String getSDPath() {
        File sdDir = null;
        boolean sdCardExist = Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED); // �ж�sd���Ƿ����
        if (sdCardExist) {
            sdDir = Environment.getExternalStorageDirectory();// ��ȡ���Ŀ¼
        }
        return sdDir.toString();
    }

    /**
     * ����ϵͳͼƬ�༭���вü�
     */
    public void startPhotoCrop(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("scale", true);
        intent.putExtra(MediaStore.EXTRA_OUTPUT,
                Uri.fromFile(new File(IMG_PATH, "temp_cropped.jpg")));
        intent.putExtra("return-data", false);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        intent.putExtra("noFaceDetection", true); // no face detection
        startActivityForResult(intent, PHOTO_RESULT);
    }

    /**
     * ���URI��ȡλͼ
     *
     * @param uri
     * @return ��Ӧ��λͼ
     */
    private Bitmap decodeUriAsBitmap(Uri uri) {
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeStream(getContentResolver()
                    .openInputStream(uri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
        return bitmap;
    }



    public String characterFilter(String fromOCR)
    {
        fromOCR = fromOCR.trim(); //trim the oce string of excess space
        String filteredString = ""; //create a final filtered string
        String subString = "";      //create a substring
        int counter = 0;            //to count repeated letters
        char previous = '~';        //start off previous with bogus character

        //Loop through the entire string length
        for(int i = 0; i< fromOCR.length(); i++)
        {

            //determine if the character is useful
            if(fromOCR.substring(i, i+1).matches("(\\w|\\t|\\r|\\n|\\s|\\." +
                    "|\\[|\\]|\\{|\\}|\\(|" +
                    "\\)|\\+|\\e|\\@|\\&|\\#)"))
            {

                //make sure there's only a few repeats., check that current char
                //does not match previous char
                if(previous == fromOCR.charAt(i))
                {
                    //set the new previous char to current
                    previous = fromOCR.charAt(i);
                    counter++; //update the counter
                    subString = subString + fromOCR.substring(i, i+1); //add to substring

                    //repeat no more than 5 times and reset
                    if(counter >= 5)
                    {
                        //reset the substring if there are too many repeats
                        subString = "";
                        //reset the counter also
                        counter = 0;
                    }
                }else if(previous != fromOCR.charAt(i))
                {
                    //get or next previous char from current char
                    previous = fromOCR.charAt(i);
                    //update our substring
                    subString = subString + fromOCR.substring(i,i+1);

                    //if repeats are minimal (less than 5) then add to final string
                    if(counter < 5)
                    {
                        //add substring to the final filtered string
                        filteredString = filteredString + subString;
                    }
                    //reset the substring
                    subString = "";
                    //reset the counter
                    counter = 0;

                }

            }

        }

        //return the final string
        return filteredString;
    }
    public String[] Split(String OCRstring){
        String[] splitString = OCRstring.split("\n|\\s{2,}");

        return splitString;

    }

    public String[] Recognizer(String OCRSplitString) {

        //Trim the string of extra spaces
        OCRSplitString = OCRSplitString.trim();
        //array of strings, String[0] is the type, string[1] is the string
        String[] recognized = new String[2];

        //telephone regex
        boolean telephone = OCRSplitString.toLowerCase().matches("((()|(t)|(tel)|(telephone))\\s*)" +
                "(\\d{9,15}+|\\d{10,25}+|(\\d{3,4}+(\\(|\\)|\\.|\\-|\\s|())*)*\\s*)");
        //fax regex
        boolean fax = OCRSplitString.toLowerCase().matches("((()|(f)|(fax))\\s*)" +
                "(\\d{9,15}+|\\d{10,25}+|(\\d{3,4}+(\\(|\\)|\\.|\\-|\\s|())*)*\\s*)");
        //Regex that matches a name
        boolean name = OCRSplitString.matches("([a-zA-Z]\\s*)*");
        //Regex that matches a US address.
        boolean addressArea = OCRSplitString.matches("([a-zA-Z]\\s*\\W*)+(\\d{4,5}\\W*)+");
        //regex that matches a US street
        boolean street = OCRSplitString.toLowerCase().matches("((\\d*|\\d+)(\\s\\w*\\s*)+)");
        //regex for apartment in case it's in a different line
        boolean apartment = OCRSplitString.toLowerCase().matches("((apt|apartment)\\s*\\d*)*");
        //regex for email
        boolean email = false;
        if(OCRSplitString.contains("@"))
        {
            email = true;
        }else if(OCRSplitString.toLowerCase().matches("(email)\\w*\\@\\w*"))
        {
            email = true;
        }

        if(telephone){
            recognized[0] = "telephone";
            recognized[1] = OCRSplitString.replaceAll("tel","").replaceAll("Tel","");
        }else if(fax) {
            recognized[0] = "fax";
            recognized[1] = OCRSplitString;
        }else if(email) {
            recognized[0] = "email";
            recognized[1] = OCRSplitString.replaceAll("email","").replaceAll("e-mail","").replaceAll("Email","").replaceAll("E-mail","");
        }else if(name) {
            recognized[0] = "name";
            recognized[1] = OCRSplitString;
        }else if(addressArea){
            recognized[0] = "area";
            recognized[1] = OCRSplitString;
        }else if(street){
            recognized[0] = "street";
            recognized[1] = OCRSplitString;
        }else if(apartment)
        {
            recognized[0] = "apartment";
            recognized[1] = OCRSplitString;
        }else
        {
            recognized[0] = "notrecognized";
            recognized[1] = OCRSplitString;

        }


        return recognized;


    }
}
