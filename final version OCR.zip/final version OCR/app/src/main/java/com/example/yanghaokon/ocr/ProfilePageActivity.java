package com.example.yanghaokon.ocr;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * Created by YJccccc on 16/2/28.
 */
public class ProfilePageActivity extends AppCompatActivity implements View.OnClickListener{

    ProfilePageActivity cv2_this=this;
    MyDBHelper lv_db;
    ArrayList<MyListData> lv_listdata;
    MyListAdapter lv_adapter;
    ArrayList nameArray;
    ArrayList<String> getDB;
    public static String IMG_PATH = getSDPath() + File.separator
            + "ocrtest";

    //dragable textview and edittext
    TextView tv_1;
    TextView tv_2;
    TextView tv_3;
    TextView tv_4;
    EditText ed_name;
    EditText ed_org;
    EditText ed_tel;
    EditText ed_email;
    EditText ed_addr;
    EditText ed_note;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_main);

        findViewById(R.id.bt_backhome).setOnClickListener(this);
        findViewById(R.id.bt_save).setOnClickListener(this);

        tv_1=(TextView)findViewById(R.id.tv_scan1);
        tv_2=(TextView)findViewById(R.id.tv_scan2);
        tv_3=(TextView)findViewById(R.id.tv_scan3);
        tv_4=(TextView)findViewById(R.id.tv_scan4);
        ed_name=(EditText)findViewById(R.id.et_name);
        ed_org=(EditText)findViewById(R.id.et_org);
        ed_tel=(EditText)findViewById(R.id.et_tel);
        ed_email=(EditText)findViewById(R.id.et_email);
        ed_addr=(EditText)findViewById(R.id.et_addr);
        ed_note=(EditText)findViewById(R.id.et_note);
        imageView=(ImageView)findViewById(R.id.imageView);


        tv_1.setOnLongClickListener(longListern);
        tv_2.setOnLongClickListener(longListern);
        tv_3.setOnLongClickListener(longListern);
        tv_4.setOnLongClickListener(longListern);
        ed_name.setOnClickListener(listern);
        ed_org.setOnClickListener(listern);
        ed_tel.setOnClickListener(listern);
        ed_email.setOnClickListener(listern);
        ed_addr.setOnClickListener(listern);
        ed_note.setOnClickListener(listern);


        tv_1.setOnDragListener(dragListern);
        tv_2.setOnDragListener(dragListern);
        tv_3.setOnDragListener(dragListern);
        tv_4.setOnDragListener(dragListern);
        ed_name.setOnDragListener(dragListern);
        ed_org.setOnDragListener(dragListern);
        ed_tel.setOnDragListener(dragListern);
        ed_email.setOnDragListener(dragListern);
        ed_addr.setOnDragListener(dragListern);
        ed_note.setOnDragListener(dragListern);
        if(getIntent().getExtras()!=null){
            Bundle bundle = this.getIntent().getExtras();

            int nameInt = bundle.getInt("nameInt");
            int addInt = bundle.getInt("addInt");
            int emailInt = bundle.getInt("emailInt");
            int telInt = bundle.getInt("telInt");
            int noteInt = bundle.getInt("noteInt");

            if (nameInt>0) {
                String name1 = bundle.getString("Name1");
                ed_name.setText(name1);
                if (nameInt>1){
                String name2 = bundle.getString("Name2");
                tv_1.setText(name2);
                    if (nameInt>2){
                        String name3 = bundle.getString("Name3");
                        tv_2.setText(name3);
                    }
                }
            }

            if (addInt>0) {
                String add1 = bundle.getString("Add1");
                ed_email.setText(add1);
                if (addInt>1){
                    String add2 = bundle.getString("Add2");
                    tv_3.setText(add2);
                }
            }

            if (emailInt>0) {
                String email1 = bundle.getString("Email1");
                ed_tel.setText(email1);
            }
            if (telInt>0) {
                String tel1 = bundle.getString("Tel1");
                ed_addr.setText(tel1);
            }

            if (noteInt>0) {
                String note1 = bundle.getString("Note1");
                ed_note.setText(note1);
                if (noteInt>1){
                    String note2 = bundle.getString("Note2");
                    tv_4.setText(note2);
                }
                if (noteInt>2){
                    if(tv_2.getText()==""){
                        tv_2.setText(bundle.getString("Note3"));
                    }
                    else if (tv_3.getText()==""){
                        tv_3.setText(bundle.getString("Note3"));
                    }
                    else if (tv_4.getText()==""){
                        tv_4.setText(bundle.getString("Note3"));
                    }
                }
                if (noteInt>3){
                    if(tv_2.getText()==""){
                        tv_2.setText(bundle.getString("Note4"));
                    }
                    else if (tv_3.getText()==""){
                        tv_3.setText(bundle.getString("Note4"));
                    }
                    else if (tv_4.getText()==""){
                        tv_4.setText(bundle.getString("Note4"));
                    }
                }

            }








        }
         Bitmap passedBitmap = decodeUriAsBitmap(Uri.fromFile(new File(IMG_PATH,
                "temp_cropped.jpg")));

        imageView.setImageBitmap(passedBitmap);


    }


    public void onClick(View v) {

        if(v.getId() == R.id.bt_save) {
            savedata();
        }
        if(v.getId() == R.id.bt_backhome) {


            AlertDialog.Builder set_builder = new AlertDialog.Builder(ProfilePageActivity.this);
            set_builder.setTitle("Leave without save?");//设置对话框标题
            set_builder.setPositiveButton("Delete and Leave", new DialogInterface.OnClickListener() {//添加确定按钮
                @Override
                public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                    // TODO Auto-generated method stub
                    Intent lv_it_home_no_save = new Intent(cv2_this, MainActivity.class);
                    startActivity(lv_it_home_no_save);
                }
            });
            set_builder.setNegativeButton("Save it", new DialogInterface.OnClickListener() {//添加返回按钮

                @Override
                public void onClick(DialogInterface dialog, int which) {//响应事件
                    // TODO Auto-generated method stub
                    savedata();
                }
            });

            set_builder.show();//在按键响应事件中显示此对话框



    }


    }

public void savedata(){
    String add_name = ed_name.getText().toString();
    String add_org = ed_org.getText().toString();
    String add_addr = ed_addr.getText().toString();
    String add_tel = ed_tel.getText().toString();
    String add_email = ed_email.getText().toString();
    String add_note = ed_note.getText().toString();
    Intent lv_it_home = new Intent(cv2_this, MainActivity.class);
    lv_it_home.putExtra("Name", add_name);
    lv_it_home.putExtra("Org", add_org);
    lv_it_home.putExtra("Addr", add_addr);
    lv_it_home.putExtra("Tel", add_tel);
    lv_it_home.putExtra("Email", add_email);
    lv_it_home.putExtra("Note", add_note);
    startActivity(lv_it_home);
}





    View.OnClickListener listern = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            DragShadow dragShadow = new DragShadow(v);
            ClipData data = ClipData.newPlainText("", "");
            v.startDrag(data,dragShadow,v,0);
        }
    };

    View.OnLongClickListener longListern = new View.OnLongClickListener(){
        @Override
        public boolean onLongClick(View v) {
            DragShadow dragShadow = new DragShadow(v);
            ClipData data = ClipData.newPlainText("", "");
            v.startDrag(data,dragShadow,v,0);
            return false;
        }
    };

    View.OnDragListener dragListern = new View.OnDragListener(){
        @Override
        public boolean onDrag(View v, DragEvent event) {
            switch (event.getAction()) {

                case DragEvent.ACTION_DRAG_ENTERED:
                    break;

                case DragEvent.ACTION_DRAG_EXITED:
                    break;

                case DragEvent.ACTION_DROP:
                    TextView target = (TextView) v;
                    TextView dragged = (TextView) event.getLocalState();
                    target.setText(dragged.getText());
                    break;
            }
            return true;
        }
    };

    private class DragShadow extends View.DragShadowBuilder{

        ColorDrawable greyBox;

        public DragShadow(View view) {
            super(view);
            greyBox = new ColorDrawable(Color.LTGRAY);
        }

        @Override
        public void onDrawShadow(Canvas canvas) {
            //super.onDrawShadow(canvas);
            greyBox.draw(canvas);
        }

        @Override
        public void onProvideShadowMetrics(Point shadowSize, Point shadowTouchPoint) {
            //super.onProvideShadowMetrics(shadowSize, shadowTouchPoint);
            View v = getView();

            int hight = (int)v.getHeight()/2;
            int width = (int)v.getWidth();

            greyBox.setBounds(-10,1,width,hight);

            shadowSize.set(width, hight);

            shadowTouchPoint.set(width,hight);
        }
    }

    private Bitmap decodeUriAsBitmap(Uri uri) {
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeStream(getContentResolver()
                    .openInputStream(uri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
        return bitmap;
    }
    public static String getSDPath() {
        File sdDir = null;
        boolean sdCardExist = Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED); // �ж�sd���Ƿ����
        if (sdCardExist) {
            sdDir = Environment.getExternalStorageDirectory();// ��ȡ���Ŀ¼
        }
        return sdDir.toString();
    }
}
